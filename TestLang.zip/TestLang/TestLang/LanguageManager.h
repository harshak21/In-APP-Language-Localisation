//
//  LanguageManager.h
//  TestLang
//
//  Created by Harsha K on 25/08/16.
//  Copyright © 2016 Harsha.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@class Locale;

@interface LanguageManager : NSObject

@property (nonatomic, copy) NSArray *availableLocales;

+ (LanguageManager *)sharedLanguageManager;
- (void)setLanguageWithLocale:(Locale *)locale;
- (Locale *)getSelectedLocale;
- (NSString *)getTranslationForKey: (NSString *)key;

@end
