//
//  Locale.m
//  TestLang
//
//  Created by Harsha K on 25/08/16.
//  Copyright © 2016 Harsha.com. All rights reserved.
//

#import "Locale.h"

@implementation Locale

- (id)initWithLanguageCode:(NSString *)languageCode languageName:(NSString *)languageName {
    
    if (self = [super init]) {
        
        self.languageCode = languageCode;
        self.languageName = languageName;
    }
    
    return self;
}


@end
