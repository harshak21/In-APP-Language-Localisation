//
//  ViewController.m
//  TestLang
//
//  Created by Harsha K on 25/08/16.
//  Copyright © 2016 Harsha.com. All rights reserved.
//

#import "ViewController.h"
#import "LanguageManager.h"
#import "Locale.h"
#import "Constants.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
 }

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidAppear:(BOOL)animated {
    self.Label.text = CustomLocalisedString(@"Label", @"the string to label");
    [_Kannada setTitle:CustomLocalisedString(@"KannadaButton", @"KannadaButton") forState:UIControlStateNormal];
    [_English setTitle:CustomLocalisedString(@"EnglishButton", @"Englsih Button") forState:UIControlStateNormal];
    
    [_segmentControl setTitle:CustomLocalisedString(@"EnglishButton", @"Englsih Button")forSegmentAtIndex:0];
    [_segmentControl setTitle:CustomLocalisedString(@"KannadaButton", @"KannadaButton")forSegmentAtIndex:1];

}

-(void)setupLocalisableElements {
    self.Label.text = CustomLocalisedString(@"Label", @"the string to label");
    [_Kannada setTitle:CustomLocalisedString(@"KannadaButton", @"KannadaButton") forState:UIControlStateNormal];
    [_English setTitle:CustomLocalisedString(@"EnglishButton", @"Englsih Button") forState:UIControlStateNormal];
    
    [_segmentControl setTitle:CustomLocalisedString(@"EnglishButton", @"Englsih Button")forSegmentAtIndex:0];
    [_segmentControl setTitle:CustomLocalisedString(@"KannadaButton", @"KannadaButton")forSegmentAtIndex:1];
    
}

- (IBAction)SegmentControl:(id)sender {
    if (_segmentControl.selectedSegmentIndex == 0)
    {
        
        LanguageManager *languageManager = [LanguageManager sharedLanguageManager];
        Locale *localeForRow = languageManager.availableLocales[0];
        localeForRow.languageName = @"English";
        NSLog(@"Language selected: %@", localeForRow.languageName);
        [languageManager setLanguageWithLocale:localeForRow];
        [self setupLocalisableElements];
        
    } else if (_segmentControl.selectedSegmentIndex ==1)
    
    {
        LanguageManager *languageManager = [LanguageManager sharedLanguageManager];
        Locale *localeForRow = languageManager.availableLocales[1];
        localeForRow.languageName = @"Kannada";
        NSLog(@"Language selected: %@", localeForRow.languageName);
        [languageManager setLanguageWithLocale:localeForRow];
        [self setupLocalisableElements];
        
    }
}

@end
