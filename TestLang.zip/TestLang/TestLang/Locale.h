//
//  Locale.h
//  TestLang
//
//  Created by Harsha K on 25/08/16.
//  Copyright © 2016 Harsha.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Locale : NSObject

@property (nonatomic, copy) NSString *languageName;
@property (nonatomic, copy) NSString *languageCode;

- (id)initWithLanguageCode:(NSString *)languageCode languageName:(NSString *)languageName;

@end
