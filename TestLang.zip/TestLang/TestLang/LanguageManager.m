//
//  LanguageManager.m
//  TestLang
//
//  Created by Harsha K on 25/08/16.
//  Copyright © 2016 Harsha.com. All rights reserved.
//

#import "LanguageManager.h"
#import "Locale.h"
#import "Constants.h"

@implementation LanguageManager

#pragma mark - Object Lifecycle
+ (LanguageManager *)sharedLanguageManager{
    
    //Create a singletin.
    static dispatch_once_t once;
    static LanguageManager *languageManager;
    dispatch_once(&once, ^ { languageManager = [[LanguageManager alloc] init]; });
    return languageManager;
}

-(id)init {
    if(self = [super init]){
        Locale *english = [[Locale alloc] initWithLanguageCode:@"en" languageName:@"English"];
        Locale *kannada = [[Locale alloc] initWithLanguageCode:@"kn" languageName:@"Kannada"];
        
        self.availableLocales = @[english, kannada];
    }
    return self;
}
- (void)setLanguageWithLocale:(Locale *)locale {
    [[NSUserDefaults standardUserDefaults]setObject:locale.languageCode forKey:DEFAULTS_KEY_LANGUAGE_CODE];
    [[NSUserDefaults standardUserDefaults]synchronize];
}

-(Locale *)getSelectedLocale {
    Locale *selectedLocale = nil;
    
    NSString *languageCode = [[[NSUserDefaults standardUserDefaults]stringForKey:DEFAULTS_KEY_LANGUAGE_CODE]lowercaseString];
    
    for (Locale *locale in self.availableLocales){
        
        if([locale.languageCode caseInsensitiveCompare:languageCode] == NSOrderedSame){
            selectedLocale = locale;
            break;
        }
    }
    return selectedLocale;
}

-(NSString *)getTranslationForKey:(NSString *)key {
    NSString *languageCode = [[[NSUserDefaults standardUserDefaults]stringForKey:DEFAULTS_KEY_LANGUAGE_CODE]lowercaseString];
    
    NSString *bundlePath = [[NSBundle mainBundle]pathForResource:languageCode ofType:@"lproj"];
    NSBundle *languageBundle = [NSBundle bundleWithPath:bundlePath];
    
    NSString *translatedString = [languageBundle localizedStringForKey:key value:@"" table:nil];
    
    if (translatedString.length<1) {
        translatedString = NSLocalizedStringWithDefaultValue(key, nil, [NSBundle mainBundle], key, key);
    }
    return translatedString;
}


@end
