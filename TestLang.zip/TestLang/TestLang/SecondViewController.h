//
//  SecondViewController.h
//  TestLang
//
//  Created by Harsha K on 01/09/16.
//  Copyright © 2016 Harsha.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *SecondLabel;

@end
