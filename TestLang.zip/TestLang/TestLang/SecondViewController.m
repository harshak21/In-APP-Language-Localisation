//
//  SecondViewController.m
//  TestLang
//
//  Created by Harsha K on 01/09/16.
//  Copyright © 2016 Harsha.com. All rights reserved.
//

#import "SecondViewController.h"
#import "LanguageManager.h"
#import "Locale.h"
#import "Constants.h"

@interface SecondViewController ()

@end

@implementation SecondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self ola];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)ola {
    self.SecondLabel.text = CustomLocalisedString(@"Label", @"the string to label");
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
